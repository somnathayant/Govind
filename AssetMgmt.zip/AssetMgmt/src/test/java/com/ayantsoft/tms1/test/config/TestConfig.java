package com.ayantsoft.tms1.test.config;


import org.springframework.context.annotation.ComponentScan; 
@ComponentScan(basePackages = "com.ayantsoft.tms") 
public class TestConfig {

}
