package com.ayatsoft.tms.model;

import java.util.Date;

public class Task {
	String id;
	String name;
	String assignee;
	String depertment;
	String piority;
	String status;
	String userType;
	String owner;
	String taskGroup;
	Date actualStartDate;
	Date actualEndDate;
	Date startDate;
	Date endDate;
	
	
	
	public Task() {
		super();
	}
	public Task(String id, String name, String assignee, String depertment, String piority, String status,
			String userType, String owner, String taskGroup, Date actualStartDate, Date actualEndDate, Date startDate,
			Date endDate) {
		super();
		this.id = id;
		this.name = name;
		this.assignee = assignee;
		this.depertment = depertment;
		this.piority = piority;
		this.status = status;
		this.userType = userType;
		this.owner = owner;
		this.taskGroup = taskGroup;
		this.actualStartDate = actualStartDate;
		this.actualEndDate = actualEndDate;
		this.startDate = startDate;
		this.endDate = endDate;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAssignee() {
		return assignee;
	}
	public void setAssignee(String assignee) {
		this.assignee = assignee;
	}
	public String getDepertment() {
		return depertment;
	}
	public void setDepertment(String depertment) {
		this.depertment = depertment;
	}
	public String getPiority() {
		return piority;
	}
	public void setPiority(String piority) {
		this.piority = piority;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	public String getTaskGroup() {
		return taskGroup;
	}
	public void setTaskGroup(String taskGroup) {
		this.taskGroup = taskGroup;
	}
	public Date getActualStartDate() {
		return actualStartDate;
	}
	public void setActualStartDate(Date actualStartDate) {
		this.actualStartDate = actualStartDate;
	}
	public Date getActualEndDate() {
		return actualEndDate;
	}
	public void setActualEndDate(Date actualEndDate) {
		this.actualEndDate = actualEndDate;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	
	
	

}
