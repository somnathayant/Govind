package com.ayatsoft.tms.dto;

public class LoginInfo {
	 private String userId;
	 private String password;
	 private Integer dataValue;
	 
	//getter and setter
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Integer getDataValue() {
		return dataValue;
	}
	public void setDataValue(Integer dataValue) {
		this.dataValue = dataValue;
	}
	 
	 
	 
	   
}
