package com.ayatsoft.tms.model;

public class Depertment {
	String id;
	String name;

	public Depertment(String id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	public Depertment() {
		super();
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}


}
