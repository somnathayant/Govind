package com.ayantsoft.tms.dao;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.ayatsoft.tms.dto.LoginInfo;
import com.ayatsoft.tms.model.User;
@Repository
public class UserDaoImpl implements UserDao{
	
	@Autowired
	MongoTemplate mongoTemplate;
	private static final String COLLECTION_NAME="user";
	
	@Override
	public List<User> listUser() {
		return mongoTemplate.findAll(User.class, COLLECTION_NAME);
	}

	@Override
	public void addUser(LoginInfo user) {
		System.out.println("Daoo");
		
		/*if(!mongoTemplate.collectionExists(User.class)){
			mongoTemplate.createCollection(User.class);
		}*/
		//user.setUserId(UUID.randomUUID().toString());
		mongoTemplate.insert(user,COLLECTION_NAME);
	
	}

	@Override
	public void updateUser(User user) {
		mongoTemplate.save(user);
		
	}

	@Override
	public void delete(User user) {
		mongoTemplate.remove(user, COLLECTION_NAME);
		
	}

	@Override
	public User findUserById(String id) {
		//System.out.println("Dao");
		return mongoTemplate.findById(id, User.class);
	}

}
