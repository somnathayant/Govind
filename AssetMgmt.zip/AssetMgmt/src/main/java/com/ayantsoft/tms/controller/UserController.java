package com.ayantsoft.tms.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.ayantsoft.tms.service.UserService;
import com.ayatsoft.tms.dto.LoginInfo;
import com.ayatsoft.tms.dto.Response;
import com.ayatsoft.tms.model.User;

@RestController
public class UserController{

	@Autowired
	UserService userService;
	
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView getLogin(){
		System.out.println("getUser");
		ModelAndView mv=new ModelAndView();
		mv.setViewName("loginPage");
		return mv;
	}
	@RequestMapping(value = "/loginPage", method = RequestMethod.GET)
	public ModelAndView getAgainLogin(){
		System.out.println("getUser");
		ModelAndView mv=new ModelAndView();
		mv.setViewName("loginPage");
		return mv;
	}
	@RequestMapping(value = "/loginPageEx", method = RequestMethod.GET)
	public ModelAndView getAgainLoginEx(){
		System.out.println("getUser");
		ModelAndView mv=new ModelAndView();
		mv.setViewName("loginPage");
		return mv;
	}
	@RequestMapping(value = "/welcome", method = RequestMethod.GET)
	public ModelAndView getWelcome(){
		System.out.println("getWelcome");
		ModelAndView mv=new ModelAndView();
		mv.setViewName("homepage");
		return mv;
	}
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public ModelAndView getLogoutPage(){
		System.out.println("getLogoutPage");
		ModelAndView mv=new ModelAndView();
		mv.setViewName("loginPage");
		return mv;
	}
	
	@RequestMapping(value = "/jUnit", method = RequestMethod.GET)
	public String getJunit(){
			return "som";
	}
	
	@RequestMapping(value = "/addUser", method = RequestMethod.POST)
	public ResponseEntity<?> addUser(@RequestBody LoginInfo user){
		System.out.println("addUser");
          HttpStatus httpStatus = null;
          Response res=new Response();
		try{
			System.out.println(user.getPassword());
			System.out.println(user.getUserId());
			userService.addUser(user);
			res.setRe("ok");
		    httpStatus = HttpStatus.CREATED;
		}catch(Exception e){
			httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
		}
		return new ResponseEntity<Response>(res, httpStatus);
	}

	@RequestMapping(value = "/getUser", method = RequestMethod.GET)
	public ResponseEntity<List<LoginInfo>> getUser(){
		System.out.println("getUser");
          HttpStatus httpStatus = null;
          List<LoginInfo> loginList=new ArrayList<LoginInfo>();
          
         	try{
         		 LoginInfo login=new LoginInfo();
                 login.setDataValue(2000);
                 LoginInfo login1=new LoginInfo();
                 login1.setDataValue(3000);
                 LoginInfo login2=new LoginInfo();
                 login2.setDataValue(4000);
                 LoginInfo login3=new LoginInfo();
                 login3.setDataValue(5000);
               loginList.add(login);
               loginList.add(login1);
               loginList.add(login2);
               loginList.add(login3);
       	
			httpStatus = HttpStatus.CREATED;
		}catch(Exception e){
			httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
		}
		return new ResponseEntity<List<LoginInfo>>(loginList, httpStatus);
	}
	
}
