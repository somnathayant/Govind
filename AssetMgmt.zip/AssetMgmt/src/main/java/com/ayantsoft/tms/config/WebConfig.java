package com.ayantsoft.tms.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoDbFactory;
import org.springframework.web.servlet.config.annotation.DefaultServletHandlerConfigurer;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.web.servlet.view.JstlView;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import com.mongodb.MongoClient;

@EnableWebMvc
@Configuration
@ComponentScan({"com.ayantsoft"})
@Import(value = { LoginSecurityConfig.class })
public class WebConfig extends WebMvcConfigurerAdapter{

 @Bean
  public InternalResourceViewResolver viewResolver(){
	  
	 InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
	  viewResolver.setViewClass(JstlView.class);
	  viewResolver.setPrefix("/WEB-INF/jsp/user/");
	  viewResolver.setSuffix(".jsp");
	  return viewResolver;
  }

 /*@Bean(name = "dataSource")
	public DriverManagerDataSource dataSource() {
	    DriverManagerDataSource driverManagerDataSource = new DriverManagerDataSource();
	    driverManagerDataSource.setDriverClassName("com.mysql.jdbc.Driver");
	    driverManagerDataSource.setUrl("jdbc:mysql://localhost:3306/employee");
	    driverManagerDataSource.setUsername("root");
	    driverManagerDataSource.setPassword("mysql");
	    return driverManagerDataSource;
	}
*/
 @Bean
 public MongoDbFactory mongoDbFactory(){
	 SimpleMongoDbFactory simpleMongoDbFactory = null;
	simpleMongoDbFactory =	new SimpleMongoDbFactory(new MongoClient("localhost",27017),"AssetMgmt");
	return simpleMongoDbFactory;
}
@Bean
 public MongoTemplate mongoTemplate(){
	
	return new MongoTemplate(mongoDbFactory());
	
}

@Override
public void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer) {
    configurer.enable();
}
public void addResourceHandlers(ResourceHandlerRegistry registry) {
    registry.addResourceHandler("/assets/**").addResourceLocations("/assets/");
}


}
